-- Order Management System: database setup
-- Run this whole script once in MySQL Workbench (File > Open SQL Script > Run).

CREATE DATABASE IF NOT EXISTS ecommerce_db;
USE ecommerce_db;

DROP TABLE IF EXISTS Orders;

CREATE TABLE Orders (
    order_id      INT PRIMARY KEY,
    customer_name VARCHAR(100),
    product_name  VARCHAR(100),
    quantity      INT,
    status        VARCHAR(30),
    unit_price    DOUBLE
);

-- Sample data for testing.
-- IDs 101-108 are used here, so the demo insertion (menu option 1) can use IDs 1, 2, 3
-- without conflicting. Statuses: Pending, Shipped, Delivered, Cancelled.
-- Quantities both > 2 and <= 2.
INSERT INTO Orders (order_id, customer_name, product_name, quantity, status, unit_price) VALUES
(101, 'Amit Sharma',  'Laptop',          3, 'Pending',   55000.00),
(102, 'Neha Verma',   'Headphones',      5, 'Shipped',    2499.50),
(103, 'Rahul Singh',  'Keyboard',        4, 'Pending',    1299.00),
(104, 'Priya Gupta',  'Wireless Mouse',  2, 'Cancelled',   699.00),
(105, 'Karan Mehta',  'Smartphone',      6, 'Pending',   18999.00),
(106, 'Sneha Iyer',   'Monitor',         1, 'Delivered', 12499.00),
(107, 'Vikram Rao',   'USB Cable',      10, 'Delivered',    199.00),
(108, 'Anjali Nair',  'Backpack',        2, 'Cancelled',   1499.00);

SELECT * FROM Orders;
