package com.ecommerce;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * All order operations. Every SQL statement uses PreparedStatement and
 * try-with-resources so statements / result sets are always closed.
 */
public class OrderManagement {

    private static final String[] VALID_STATUSES = {"Pending", "Shipped", "Delivered"};
    private static final int DUPLICATE_KEY_ERROR = 1062;

    private final Scanner scanner;

    public OrderManagement(Scanner scanner) {
        this.scanner = scanner;
    }

    // ------------------------------------------------------------------
    // A. Insert three orders
    // ------------------------------------------------------------------
    public void insertOrders() {
        String sql = "INSERT INTO Orders (order_id, customer_name, product_name, quantity, status, unit_price) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection()) {
            if (con == null) {
                return;
            }
            System.out.println("\nEnter details for 3 orders.");
            int inserted = 0;
            while (inserted < 3) {
                System.out.println("\n--- Order " + (inserted + 1) + " of 3 ---");
                int id = readPositiveInt("Order ID: ");
                String customer = readNonEmpty("Customer Name: ");
                String product = readNonEmpty("Product Name: ");
                int quantity = readPositiveInt("Quantity: ");
                String status = readNonEmpty("Status (e.g. Pending, Shipped, Delivered, Cancelled): ");
                double price = readNonNegativeDouble("Unit Price: ");

                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, id);
                    ps.setString(2, customer);
                    ps.setString(3, product);
                    ps.setInt(4, quantity);
                    ps.setString(5, status);
                    ps.setDouble(6, price);
                    ps.executeUpdate();
                    inserted++;
                    System.out.println("Order " + id + " inserted successfully!");
                } catch (SQLException e) {
                    if (e.getErrorCode() == DUPLICATE_KEY_ERROR) {
                        System.out.println("Order ID already exists! Please enter another ID.");
                        // loop again: same order number, user enters a new ID
                    } else {
                        System.out.println("Error inserting order: " + e.getMessage());
                        return;
                    }
                }
            }
            System.out.println("\nAll 3 orders inserted successfully!");
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------
    // B. Search orders by status (quantity > 2, unit_price DESC)
    // ------------------------------------------------------------------
    public void searchOrdersByStatus() {
        String sql = "SELECT * FROM Orders WHERE status = ? AND quantity > 2 ORDER BY unit_price DESC";

        String status = readNonEmpty("Enter status to search: ");

        try (Connection con = DBConnection.getConnection()) {
            if (con == null) {
                return;
            }
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, status);
                try (ResultSet rs = ps.executeQuery()) {
                    boolean found = false;
                    while (rs.next()) {
                        if (!found) {
                            printTableHeader();
                            found = true;
                        }
                        printRow(rs);
                    }
                    if (found) {
                        printTableFooter();
                    } else {
                        System.out.println("No matching orders found.");
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------
    // C. Increase quantity
    // ------------------------------------------------------------------
    public void increaseQuantity() {
        String sql = "UPDATE Orders SET quantity = quantity + ? WHERE order_id = ?";

        int id = readPositiveInt("Enter Order ID: ");
        int extra = readInt("Enter additional quantity: ");
        if (extra <= 0) {
            System.out.println("Additional quantity must be greater than zero!");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            if (con == null) {
                return;
            }
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, extra);
                ps.setInt(2, id);
                int rows = ps.executeUpdate();
                if (rows > 0) {
                    System.out.println("Order quantity updated successfully!");
                } else {
                    System.out.println("Order ID not found!");
                }
            }
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------
    // D. Update order status
    // ------------------------------------------------------------------
    public void updateOrderStatus() {
        String selectSql = "SELECT * FROM Orders WHERE order_id = ?";
        String updateSql = "UPDATE Orders SET status = ? WHERE order_id = ?";

        int id = readPositiveInt("Enter Order ID: ");

        try (Connection con = DBConnection.getConnection()) {
            if (con == null) {
                return;
            }

            // 1. Retrieve and show current details
            if (!showOrder(con, selectSql, id, "Current order details:")) {
                System.out.println("Order not found!");
                return;
            }

            // 2. Read and validate new status
            String input = readNonEmpty("Enter new status (Pending / Shipped / Delivered): ");
            String newStatus = normaliseStatus(input);
            if (newStatus == null) {
                System.out.println("Invalid status! Allowed values: Pending, Shipped, Delivered.");
                return;
            }

            // 3. Update
            try (PreparedStatement ps = con.prepareStatement(updateSql)) {
                ps.setString(1, newStatus);
                ps.setInt(2, id);
                ps.executeUpdate();
            }
            System.out.println("Order status updated successfully!");

            // 4. Show updated record
            showOrder(con, selectSql, id, "Updated order details:");
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------
    // E1. Total order value
    // ------------------------------------------------------------------
    public void displayTotalOrderValue() {
        String sql = "SELECT SUM(quantity * unit_price) AS total_value FROM Orders";

        try (Connection con = DBConnection.getConnection()) {
            if (con == null) {
                return;
            }
            try (PreparedStatement ps = con.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                double total = 0.0;
                if (rs.next()) {
                    total = rs.getDouble("total_value"); // NULL (empty table) becomes 0.0
                }
                System.out.printf("Total Order Value: %.2f%n", total);
            }
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------
    // E2. Delete cancelled order
    // ------------------------------------------------------------------
    public void deleteCancelledOrder() {
        String checkSql = "SELECT status FROM Orders WHERE order_id = ?";
        String deleteSql = "DELETE FROM Orders WHERE order_id = ? AND status = 'Cancelled'";

        int id = readPositiveInt("Enter Order ID to delete: ");

        try (Connection con = DBConnection.getConnection()) {
            if (con == null) {
                return;
            }

            String currentStatus = null;
            try (PreparedStatement ps = con.prepareStatement(checkSql)) {
                ps.setInt(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        currentStatus = rs.getString("status");
                    }
                }
            }

            if (currentStatus == null) {
                System.out.println("Order ID not found!");
                return;
            }
            if (!currentStatus.equalsIgnoreCase("Cancelled")) {
                System.out.println("Cannot delete order! Only Cancelled orders can be deleted.");
                return;
            }

            try (PreparedStatement ps = con.prepareStatement(deleteSql)) {
                ps.setInt(1, id);
                int rows = ps.executeUpdate();
                if (rows > 0) {
                    System.out.println("Cancelled order deleted successfully!");
                } else {
                    System.out.println("Cannot delete order! Only Cancelled orders can be deleted.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------
    // Helpers: display
    // ------------------------------------------------------------------
    private boolean showOrder(Connection con, String selectSql, int id, String heading) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(selectSql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return false;
                }
                System.out.println("\n" + heading);
                printTableHeader();
                printRow(rs);
                printTableFooter();
                return true;
            }
        }
    }

    private static final String ROW_FORMAT = "| %-8s | %-20s | %-20s | %-8s | %-10s | %12s |%n";

    private void printTableHeader() {
        String line = tableLine();
        System.out.println(line);
        System.out.printf(ROW_FORMAT, "OrderID", "Customer", "Product", "Quantity", "Status", "Unit Price");
        System.out.println(line);
    }

    private void printRow(ResultSet rs) throws SQLException {
        System.out.printf(ROW_FORMAT,
                rs.getInt("order_id"),
                truncate(rs.getString("customer_name"), 20),
                truncate(rs.getString("product_name"), 20),
                rs.getInt("quantity"),
                truncate(rs.getString("status"), 10),
                String.format("%.2f", rs.getDouble("unit_price")));
    }

    private void printTableFooter() {
        System.out.println(tableLine());
    }

    private String tableLine() {
        return "+----------+----------------------+----------------------+----------+------------+--------------+";
    }

    private String truncate(String s, int max) {
        if (s == null) {
            return "";
        }
        return s.length() <= max ? s : s.substring(0, max - 1) + "~";
    }

    private String normaliseStatus(String input) {
        for (String valid : VALID_STATUSES) {
            if (valid.equalsIgnoreCase(input.trim())) {
                return valid;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------
    // Helpers: safe console input (never crashes on bad input)
    // ------------------------------------------------------------------
    private String readNonEmpty(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            if (!line.isEmpty()) {
                return line;
            }
            System.out.println("Input cannot be empty. Try again.");
        }
    }

    private int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    private int readPositiveInt(String prompt) {
        while (true) {
            int value = readInt(prompt);
            if (value > 0) {
                return value;
            }
            System.out.println("Value must be greater than zero.");
        }
    }

    private double readNonNegativeDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                double value = Double.parseDouble(line);
                if (value >= 0) {
                    return value;
                }
                System.out.println("Value cannot be negative.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}
