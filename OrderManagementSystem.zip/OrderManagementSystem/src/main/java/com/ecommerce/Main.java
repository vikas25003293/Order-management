package com.ecommerce;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Quick connection test so problems show up immediately.
        try (Connection con = DBConnection.getConnection()) {
            if (con == null) {
                System.out.println("Exiting: could not connect to the database.");
                return;
            }
            System.out.println("Connected to MySQL successfully!");
        } catch (SQLException e) {
            System.out.println("Connection error: " + e.getMessage());
            return;
        }

        Scanner scanner = new Scanner(System.in);
        OrderManagement manager = new OrderManagement(scanner);
        int choice = -1;

        try {
            do {
                printMenu();
                String line = scanner.nextLine().trim();
                try {
                    choice = Integer.parseInt(line);
                } catch (NumberFormatException e) {
                    choice = -1;
                }

                switch (choice) {
                    case 1:
                        manager.insertOrders();
                        break;
                    case 2:
                        manager.searchOrdersByStatus();
                        break;
                    case 3:
                        manager.increaseQuantity();
                        break;
                    case 4:
                        manager.updateOrderStatus();
                        break;
                    case 5:
                        manager.displayTotalOrderValue();
                        break;
                    case 6:
                        manager.deleteCancelledOrder();
                        break;
                    case 0:
                        System.out.println("Thank you for using Order Management System. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice! Please enter a number from 0 to 6.");
                }
            } while (choice != 0);
        } catch (NoSuchElementException e) {
            System.out.println("\nInput closed. Exiting.");
        } finally {
            scanner.close();
        }
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("========== ORDER MANAGEMENT SYSTEM ==========");
        System.out.println();
        System.out.println("1. Insert Three Orders");
        System.out.println("2. Search Orders by Status");
        System.out.println("3. Increase Order Quantity");
        System.out.println("4. Update Order Status");
        System.out.println("5. Display Total Order Value");
        System.out.println("6. Delete Cancelled Order");
        System.out.println("0. Exit");
        System.out.println();
        System.out.print("Enter your choice: ");
    }
}
