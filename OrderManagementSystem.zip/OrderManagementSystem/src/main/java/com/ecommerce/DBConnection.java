package com.ecommerce;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Creates MySQL connections using JDBC DriverManager.
 * Settings are read from src/main/resources/db.properties
 * (copy db.properties.example to db.properties and enter your MySQL password).
 */
public class DBConnection {

    private static final String PROPERTIES_FILE = "db.properties";

    private static final String DEFAULT_URL = "jdbc:mysql://localhost:3306/ecommerce_db";
    private static final String DEFAULT_USER = "root";
    private static final String PLACEHOLDER_PASSWORD = "YOUR_MYSQL_PASSWORD";

    private static String url = DEFAULT_URL;
    private static String user = DEFAULT_USER;
    private static String password = PLACEHOLDER_PASSWORD;
    private static boolean configFound = false;

    static {
        Properties props = new Properties();
        try (InputStream in = DBConnection.class.getClassLoader().getResourceAsStream(PROPERTIES_FILE)) {
            if (in != null) {
                props.load(in);
                url = props.getProperty("db.url", DEFAULT_URL).trim();
                user = props.getProperty("db.username", DEFAULT_USER).trim();
                password = props.getProperty("db.password", "");
                configFound = true;
            }
        } catch (IOException e) {
            System.out.println("Could not read " + PROPERTIES_FILE + ": " + e.getMessage());
        }
    }

    private DBConnection() {
    }

    /** Returns a new connection, or null if it fails (a clear message is printed). */
    public static Connection getConnection() {
        if (!configFound) {
            System.out.println("Configuration file db.properties was not found.");
            System.out.println("Copy src/main/resources/db.properties.example to "
                    + "src/main/resources/db.properties, enter your MySQL password, then run again.");
            return null;
        }
        if (PLACEHOLDER_PASSWORD.equals(password)) {
            System.out.println("Please replace YOUR_MYSQL_PASSWORD in db.properties with your real MySQL password.");
            return null;
        }
        try {
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            System.out.println(explain(e));
            return null;
        }
    }

    /** Turns common connection errors into understandable messages. */
    private static String explain(SQLException e) {
        int code = e.getErrorCode();
        if (code == 1045) {
            return "Incorrect MySQL username or password. Check db.username and db.password in db.properties.";
        }
        if (code == 1049) {
            return "Database 'ecommerce_db' does not exist. Run database/ecommerce_db.sql in MySQL Workbench first.";
        }
        String state = e.getSQLState();
        if (state != null && state.startsWith("08")) {
            return "Cannot reach MySQL server. Make sure MySQL is running and the port in db.url (3306) is correct.";
        }
        return "Database connection failed: " + e.getMessage();
    }
}
